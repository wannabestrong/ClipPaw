# Clipboard History

Minimal Windows 10/11 clipboard history manager built with Tauri 2, React, TypeScript, and SQLite.

## Current status

Core clipboard capture and interaction are complete:

- Native Windows clipboard listener (`AddClipboardFormatListener`)
- Local SQLite history with SHA-256 de-duplication
- Search, pin, delete, copy, keyboard navigation, and `Ctrl+Shift+V` global shortcut
- System tray menu (open, settings, pause listener, quit)
- Settings for maximum history size and automatic cleanup age
- Paused-listening state and cleanup of unpinned records
- Optional Windows login auto-start (stored in the user Run entry)

The Release executable builds successfully. Installer generation requires the WiX toolchain; on a clean machine Tauri downloads it on first packaging run.

## Development environment

- Node.js 20+
- pnpm 11+
- Rust stable MSVC
- Visual Studio Build Tools with C++ tools and Windows SDK

Build tools and Cargo caches are reused from the machine and kept outside the project. The project itself is located at `G:\ClipBoard`.

## Run in development

```powershell
cd G:\ClipBoard
pnpm install
cmd.exe /d /c 'call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul && set "CARGO_HOME=G:\DevTools\cargo" && set "PATH=C:\Users\KDU\.cargo\bin;%PATH%" && pnpm tauri dev'
```

## Data and privacy

Clipboard records are stored locally in the Windows application data directory. No clipboard content is uploaded or sent to a remote service.
